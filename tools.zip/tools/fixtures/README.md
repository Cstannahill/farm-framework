# Tools: Fixtures

Sample configuration and response files used by tests and examples.

- **mock-farm-config.ts** – example `farm.config.ts` demonstrating a
  fully populated AI section.
- **docker-responses.json** – placeholder for mocked Docker API
  responses.
