import { describe, it, expect, beforeEach, vi } from "vitest";
import { TypeSyncOrchestrator } from "../../../packages/type-sync/src/orchestrator";
import type { SyncOptions } from "../../../packages/type-sync/src/orchestrator";
import fs from "fs-extra";

// Mock fs-extra
vi.mock("fs-extra");
const mockFs = vi.mocked(fs);

describe("TypeSync Orchestrator Minimal Test", () => {
  let orchestrator: TypeSyncOrchestrator;
  let mockConfig: SyncOptions;

  beforeEach(() => {
    // Reset all mocks
    vi.clearAllMocks();

    // Setup basic fs mocks
    mockFs.ensureDir.mockResolvedValue(undefined);
    mockFs.pathExists.mockResolvedValue(false); // No existing cache initially
    mockFs.readdir.mockResolvedValue([]);
    mockFs.readJson.mockResolvedValue({});

    orchestrator = new TypeSyncOrchestrator();
    mockConfig = {
      apiUrl: "http://localhost:8000",
      outputDir: "./generated",
      features: {
        client: true,
        hooks: true,
        streaming: true,
        aiHooks: true,
      },
      performance: {
        enableMonitoring: true,
        enableIncrementalGeneration: false, // Disable to avoid loadFileChecksums
        maxConcurrency: 4,
        cacheTimeout: 300000,
      },
    };
  });

  it("should initialize orchestrator", async () => {
    await orchestrator.initialize(mockConfig);
    expect(mockFs.ensureDir).toHaveBeenCalledWith("./generated");
  });
});
