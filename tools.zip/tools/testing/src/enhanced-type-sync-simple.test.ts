// Enhanced Type-Sync API Compatibility Tests
import { describe, it, expect } from "vitest";
import {
  TypeSyncOrchestrator,
  GenerationCache,
  OpenAPIExtractor,
  AIHookGenerator,
  type SyncOptions,
  type SyncResult,
  type OpenAPISchema,
} from "@farm/type-sync";

describe("Enhanced Type-Sync API Compatibility", () => {
  describe("TypeSyncOrchestrator", () => {
    it("should be instantiable and have required methods", () => {
      const orchestrator = new TypeSyncOrchestrator();

      expect(orchestrator).toBeDefined();
      expect(typeof orchestrator.initialize).toBe("function");
      expect(typeof orchestrator.syncOnce).toBe("function");
      expect(typeof orchestrator.registerGenerator).toBe("function");
    });

    it("should have proper initialize method signature", async () => {
      const orchestrator = new TypeSyncOrchestrator();
      const mockConfig: SyncOptions = {
        apiUrl: "http://localhost:8000",
        outputDir: "./test-generated",
        features: {
          client: true,
          hooks: true,
          streaming: true,
          aiHooks: true,
        },
      };

      // This should not throw a type error
      expect(async () => {
        await orchestrator.initialize(mockConfig);
      }).toBeDefined();
    });
  });

  describe("GenerationCache", () => {
    it("should be instantiable with correct constructor signature", () => {
      // Test constructor with baseDir
      const cache1 = new GenerationCache("./test-cache");
      expect(cache1).toBeDefined();

      // Test constructor with baseDir and options
      const cache2 = new GenerationCache("./test-cache", {
        timeout: 60000,
        enableCompression: true,
      });
      expect(cache2).toBeDefined();
    });

    it("should have async methods with proper signatures", () => {
      const cache = new GenerationCache("./test-cache");

      expect(typeof cache.initialize).toBe("function");
      expect(typeof cache.get).toBe("function");
      expect(typeof cache.set).toBe("function");
      expect(typeof cache.hashSchema).toBe("function");
    });

    it("should expect proper CacheEntry format", () => {
      const cache = new GenerationCache("./test-cache");

      // This should be the correct CacheEntry format
      const validEntry = {
        schema: { openapi: "3.0.0" },
        results: { generated: "code" },
        timestamp: Date.now(),
        version: "1.0",
      };

      // This should not cause type errors
      expect(async () => {
        await cache.set("test-hash", validEntry);
      }).toBeDefined();
    });
  });

  describe("OpenAPIExtractor", () => {
    it("should be instantiable and have extractFromFastAPI method", () => {
      const extractor = new OpenAPIExtractor();

      expect(extractor).toBeDefined();
      expect(typeof extractor.extractFromFastAPI).toBe("function");
    });

    it("should have proper extractFromFastAPI signature", () => {
      const extractor = new OpenAPIExtractor();

      // This should not cause type errors
      expect(async () => {
        await extractor.extractFromFastAPI(
          "http://localhost:8000",
          "./output.json",
          { timeout: 30000 }
        );
      }).toBeDefined();
    });
  });

  describe("AIHookGenerator", () => {
    it("should be instantiable and have generate method", () => {
      const generator = new AIHookGenerator();

      expect(generator).toBeDefined();
      expect(typeof generator.generate).toBe("function");
    });

    it("should require outputDir in options", () => {
      const generator = new AIHookGenerator();
      const mockSchema: OpenAPISchema = {
        openapi: "3.0.0",
        info: { title: "Test API", version: "1.0.0" },
        paths: {},
      };

      // This should not cause type errors
      expect(async () => {
        await generator.generate(mockSchema, {
          outputDir: "./test-hooks",
        });
      }).toBeDefined();
    });

    it("should return AIGenerationResult with path property", async () => {
      const generator = new AIHookGenerator();
      const mockSchema: OpenAPISchema = {
        openapi: "3.0.0",
        info: { title: "Test API", version: "1.0.0" },
        paths: {},
      };

      // The result should have path property, not files array
      const result = generator.generate(mockSchema, {
        outputDir: "./test-hooks",
      });

      expect(result).toBeInstanceOf(Promise);

      // Type check - this should compile without errors
      result.then((res) => {
        expect(typeof res.path).toBe("string");
        // Should not have files property
        expect((res as any).files).toBeUndefined();
      });
    });
  });

  describe("Type Definitions", () => {
    it("should have proper SyncOptions interface", () => {
      const validOptions: SyncOptions = {
        apiUrl: "http://localhost:8000",
        outputDir: "./generated",
        features: {
          client: true,
          hooks: true,
          streaming: true,
          aiHooks: true,
        },
        performance: {
          enableMonitoring: true,
          enableIncrementalGeneration: true,
          maxConcurrency: 4,
          cacheTimeout: 300000,
        },
      };

      expect(validOptions).toBeDefined();
      expect(validOptions.apiUrl).toBe("http://localhost:8000");
      expect(validOptions.features.aiHooks).toBe(true);
    });

    it("should have proper OpenAPISchema interface", () => {
      const validSchema: OpenAPISchema = {
        openapi: "3.0.0",
        info: { title: "Test API", version: "1.0.0" },
        paths: {
          "/test": {
            get: {
              responses: {
                "200": { description: "Success" },
              },
            },
          },
        },
      };

      expect(validSchema).toBeDefined();
      expect(validSchema.openapi).toBe("3.0.0");
      expect(validSchema.info.title).toBe("Test API");
    });
  });
});
