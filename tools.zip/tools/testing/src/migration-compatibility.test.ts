// Migration Compatibility Tests
import {
  describe,
  it,
  expect,
  beforeEach,
  afterEach,
  vi,
  beforeAll,
  afterAll,
} from "vitest";
import { TypeSyncOrchestrator } from "../../../packages/type-sync/src/orchestrator";
import { CodegenOrchestrator } from "../../../packages/core/src/codegen/orchestrator";
import { TemplateProcessor } from "../../../packages/cli/src/template/processor";
import { TemplateValidator } from "../../../packages/cli/src/template/validator";
import type {
  SyncOptions,
  SyncResult,
} from "../../../packages/type-sync/src/orchestrator";
import type { CodegenOptions } from "../../../packages/core/src/codegen/types";
import fs from "fs-extra";
import path from "path";

// Mock external dependencies
vi.mock("fs-extra");
vi.mock("node-fetch");

const mockFs = vi.mocked(fs);

describe("Migration Compatibility Tests", () => {
  beforeAll(() => {
    vi.useFakeTimers();
  });

  afterAll(() => {
    vi.useRealTimers();
  });

  beforeEach(() => {
    // Setup common mocks
    mockFs.ensureDir.mockResolvedValue(undefined);
    mockFs.writeFile.mockResolvedValue(undefined);
    mockFs.readFile.mockResolvedValue("");
    mockFs.stat.mockResolvedValue({ mtime: new Date() } as any);
    mockFs.pathExists.mockResolvedValue(true);
    mockFs.readdir.mockResolvedValue([]);
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  describe("Legacy API Compatibility", () => {
    it("should maintain backward compatibility for TypeSyncOrchestrator", async () => {
      const orchestrator = new TypeSyncOrchestrator();

      // Test the legacy API format still works
      const legacyConfig: SyncOptions = {
        apiUrl: "http://localhost:8000",
        outputDir: "./generated",
        features: {
          client: true,
          hooks: true,
          streaming: true,
        },
      };

      const mockSchema = {
        openapi: "3.0.0",
        info: { title: "Legacy API", version: "1.0.0" },
        paths: {
          "/legacy": {
            get: {
              responses: { "200": { description: "Success" } },
            },
          },
        },
      };

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockSchema),
      });

      const result = await orchestrator.syncOnce(legacyConfig);

      expect(result).toBeDefined();
      expect(result.filesGenerated).toBeGreaterThan(0);
      expect(result.artifacts).toContain("types.ts");
      expect(result.artifacts).toContain("api-client.ts");
      expect(result.artifacts).toContain("hooks.ts");
    });

    it("should maintain backward compatibility for CodegenOrchestrator", async () => {
      const orchestrator = new CodegenOrchestrator();

      // Test the legacy CodegenOptions format
      const legacyConfig: CodegenOptions = {
        apiUrl: "http://localhost:8000",
        outputDir: "./generated",
        features: {
          client: true,
          hooks: true,
          streaming: true,
        },
        verbose: false,
        dryRun: false,
      };

      const mockSchema = {
        openapi: "3.0.0",
        info: { title: "Legacy Codegen API", version: "1.0.0" },
        paths: {
          "/legacy-codegen": {
            get: {
              responses: { "200": { description: "Success" } },
            },
          },
        },
      };

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockSchema),
      });

      await orchestrator.initialize(legacyConfig);
      const result = await orchestrator.run({ dryRun: false });

      expect(result).toBeDefined();
      expect(result.filesGenerated).toBeGreaterThan(0);
    });

    it("should support legacy CLI command structure", async () => {
      // Test that existing CLI commands still work with new implementation
      const orchestrator = new CodegenOrchestrator();

      // Simulate legacy `farm types:sync` command options
      const legacyCliOptions = {
        apiUrl: "http://localhost:8000",
        outputDir: ".farm/types/generated",
        features: {
          client: true,
          hooks: true,
          streaming: true,
        },
        verbose: false,
        dryRun: false,
      };

      const mockSchema = {
        openapi: "3.0.0",
        info: { title: "Legacy CLI API", version: "1.0.0" },
        paths: {
          "/users": {
            get: {
              responses: {
                "200": {
                  description: "Users list",
                  content: {
                    "application/json": {
                      schema: {
                        type: "array",
                        items: { $ref: "#/components/schemas/User" },
                      },
                    },
                  },
                },
              },
            },
          },
        },
        components: {
          schemas: {
            User: {
              type: "object",
              properties: {
                id: { type: "string" },
                name: { type: "string" },
              },
              required: ["id", "name"],
            },
          },
        },
      };

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockSchema),
      });

      await orchestrator.initialize(legacyCliOptions);
      const result = await orchestrator.run({ dryRun: false });

      expect(result).toBeDefined();
      expect(result.filesGenerated).toBeGreaterThan(0);
      expect(result.artifacts).toContain("types.ts");
    });
  });

  describe("Template System Compatibility", () => {
    it("should maintain compatibility with existing templates", async () => {
      const processor = new TemplateProcessor();

      // Test that existing template structure still works
      const legacyTemplateContent = `
        import React from 'react';
        
        export interface {{pascalCase name}}Props {
          {{#each props}}
          {{name}}: {{type}};
          {{/each}}
        }
        
        export const {{pascalCase name}}: React.FC<{{pascalCase name}}Props> = ({
          {{#each props}}{{name}}{{#unless @last}}, {{/unless}}{{/each}}
        }) => {
          return (
            <div className="{{kebabCase name}}">
              <h1>{{name}}</h1>
              {{#each props}}
              <p>{{name}}: {{{name}}}</p>
              {{/each}}
            </div>
          );
        };
      `;

      const legacyContext = {
        name: "UserProfile",
        props: [
          { name: "userId", type: "string" },
          { name: "userName", type: "string" },
          { name: "isActive", type: "boolean" },
        ],
      };

      mockFs.readdir.mockResolvedValue(["component.tsx.hbs"] as any);
      mockFs.readFile.mockResolvedValue(legacyTemplateContent);

      const result = await processor.processTemplate(
        "legacy-template",
        legacyContext,
        "./output"
      );

      expect(result).toHaveLength(1);
      expect(result[0]).toContain("UserProfile");
      expect(result[0]).toContain("userId: string");
      expect(result[0]).toContain("userName: string");
      expect(result[0]).toContain("isActive: boolean");
    });

    it("should validate existing template structures", async () => {
      const validator = new TemplateValidator();

      // Test validation of legacy template structure
      const legacyTemplateStructure = {
        "package.json.hbs":
          '{"name": "{{projectName}}", "version": "{{version}}"}',
        "src/index.ts.hbs": 'export * from "./{{moduleName}}";',
        "README.md.hbs": "# {{projectName}}\n\n{{description}}",
        "tsconfig.json.hbs": '{"compilerOptions": {"target": "{{target}}"}}',
      };

      mockFs.readdir.mockImplementation((dirPath: string) => {
        const keys = Object.keys(legacyTemplateStructure);
        return Promise.resolve(keys as any);
      });

      mockFs.readFile.mockImplementation((filePath: string) => {
        const fileName = filePath.toString().split("/").pop();
        return Promise.resolve(
          legacyTemplateStructure[
            fileName as keyof typeof legacyTemplateStructure
          ] || ""
        );
      });

      mockFs.stat.mockResolvedValue({ isFile: () => true } as any);

      const result = await validator.validateTemplate("./legacy-template");

      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
      expect(result.warnings).toBeDefined();
    });
  });

  describe("Generated Code Compatibility", () => {
    it("should generate backward-compatible TypeScript types", async () => {
      const orchestrator = new TypeSyncOrchestrator();

      // Test that generated types maintain the same structure as before
      const mockSchema = {
        openapi: "3.0.0",
        info: { title: "Compatibility API", version: "1.0.0" },
        paths: {
          "/api/v1/users": {
            get: {
              responses: {
                "200": {
                  description: "Success",
                  content: {
                    "application/json": {
                      schema: {
                        type: "array",
                        items: { $ref: "#/components/schemas/User" },
                      },
                    },
                  },
                },
              },
            },
            post: {
              requestBody: {
                content: {
                  "application/json": {
                    schema: { $ref: "#/components/schemas/CreateUserRequest" },
                  },
                },
              },
              responses: {
                "201": {
                  description: "Created",
                  content: {
                    "application/json": {
                      schema: { $ref: "#/components/schemas/User" },
                    },
                  },
                },
              },
            },
          },
        },
        components: {
          schemas: {
            User: {
              type: "object",
              properties: {
                id: { type: "string" },
                email: { type: "string", format: "email" },
                firstName: { type: "string" },
                lastName: { type: "string" },
                createdAt: { type: "string", format: "date-time" },
                updatedAt: { type: "string", format: "date-time" },
              },
              required: ["id", "email", "firstName", "lastName"],
            },
            CreateUserRequest: {
              type: "object",
              properties: {
                email: { type: "string", format: "email" },
                firstName: { type: "string" },
                lastName: { type: "string" },
              },
              required: ["email", "firstName", "lastName"],
            },
          },
        },
      };

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockSchema),
      });

      const config: SyncOptions = {
        apiUrl: "http://localhost:8000",
        outputDir: "./generated",
        features: {
          client: true,
          hooks: true,
          streaming: true,
        },
      };

      const result = await orchestrator.syncOnce(config);

      expect(result.filesGenerated).toBeGreaterThan(0);
      expect(result.artifacts).toContain("types.ts");
      expect(result.artifacts).toContain("api-client.ts");
      expect(result.artifacts).toContain("hooks.ts");

      // Verify that the expected interfaces are generated
      expect(mockFs.writeFile).toHaveBeenCalledWith(
        expect.stringContaining("types.ts"),
        expect.stringContaining("interface User"),
        "utf-8"
      );
      expect(mockFs.writeFile).toHaveBeenCalledWith(
        expect.stringContaining("types.ts"),
        expect.stringContaining("interface CreateUserRequest"),
        "utf-8"
      );
    });

    it("should generate backward-compatible API client methods", async () => {
      const orchestrator = new TypeSyncOrchestrator();

      const mockSchema = {
        openapi: "3.0.0",
        info: { title: "Client API", version: "1.0.0" },
        paths: {
          "/posts": {
            get: {
              summary: "Get all posts",
              responses: {
                "200": {
                  description: "Posts retrieved successfully",
                  content: {
                    "application/json": {
                      schema: {
                        type: "array",
                        items: { $ref: "#/components/schemas/Post" },
                      },
                    },
                  },
                },
              },
            },
            post: {
              summary: "Create a post",
              requestBody: {
                content: {
                  "application/json": {
                    schema: { $ref: "#/components/schemas/CreatePost" },
                  },
                },
              },
              responses: {
                "201": {
                  description: "Post created successfully",
                  content: {
                    "application/json": {
                      schema: { $ref: "#/components/schemas/Post" },
                    },
                  },
                },
              },
            },
          },
        },
        components: {
          schemas: {
            Post: {
              type: "object",
              properties: {
                id: { type: "string" },
                title: { type: "string" },
                content: { type: "string" },
              },
              required: ["id", "title", "content"],
            },
            CreatePost: {
              type: "object",
              properties: {
                title: { type: "string" },
                content: { type: "string" },
              },
              required: ["title", "content"],
            },
          },
        },
      };

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockSchema),
      });

      const config: SyncOptions = {
        apiUrl: "http://localhost:8000",
        outputDir: "./generated",
        features: {
          client: true,
          hooks: false,
          streaming: false,
        },
      };

      const result = await orchestrator.syncOnce(config);

      expect(result.filesGenerated).toBeGreaterThan(0);
      expect(result.artifacts).toContain("api-client.ts");

      // Verify that expected API client methods are generated
      expect(mockFs.writeFile).toHaveBeenCalledWith(
        expect.stringContaining("api-client.ts"),
        expect.stringContaining("getPosts"),
        "utf-8"
      );
      expect(mockFs.writeFile).toHaveBeenCalledWith(
        expect.stringContaining("api-client.ts"),
        expect.stringContaining("createPost"),
        "utf-8"
      );
    });
  });

  describe("Configuration Migration", () => {
    it("should handle legacy configuration formats", async () => {
      const orchestrator = new TypeSyncOrchestrator();

      // Test legacy configuration structure
      const legacyConfig = {
        apiUrl: "http://localhost:8000",
        outputDir: "./generated",
        generateClient: true, // Legacy property name
        generateHooks: true, // Legacy property name
        enableStreaming: true, // Legacy property name
      };

      const mockSchema = {
        openapi: "3.0.0",
        info: { title: "Legacy Config API", version: "1.0.0" },
        paths: {
          "/legacy-config": {
            get: {
              responses: { "200": { description: "Success" } },
            },
          },
        },
      };

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockSchema),
      });

      // The new system should handle legacy config by converting it internally
      const normalizedConfig: SyncOptions = {
        apiUrl: legacyConfig.apiUrl,
        outputDir: legacyConfig.outputDir,
        features: {
          client: legacyConfig.generateClient,
          hooks: legacyConfig.generateHooks,
          streaming: legacyConfig.enableStreaming,
        },
      };

      const result = await orchestrator.syncOnce(normalizedConfig);

      expect(result.filesGenerated).toBeGreaterThan(0);
    });

    it("should preserve existing file structure conventions", async () => {
      const orchestrator = new TypeSyncOrchestrator();

      const mockSchema = {
        openapi: "3.0.0",
        info: { title: "File Structure API", version: "1.0.0" },
        paths: {
          "/structure": {
            get: {
              responses: { "200": { description: "Success" } },
            },
          },
        },
      };

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockSchema),
      });

      const config: SyncOptions = {
        apiUrl: "http://localhost:8000",
        outputDir: "./generated",
        features: {
          client: true,
          hooks: true,
          streaming: true,
        },
      };

      const result = await orchestrator.syncOnce(config);

      // Verify that files are created with expected names and structure
      expect(mockFs.writeFile).toHaveBeenCalledWith(
        expect.stringMatching(/.*\/types\.ts$/),
        expect.any(String),
        "utf-8"
      );
      expect(mockFs.writeFile).toHaveBeenCalledWith(
        expect.stringMatching(/.*\/api-client\.ts$/),
        expect.any(String),
        "utf-8"
      );
      expect(mockFs.writeFile).toHaveBeenCalledWith(
        expect.stringMatching(/.*\/hooks\.ts$/),
        expect.any(String),
        "utf-8"
      );
    });
  });

  describe("Error Handling Migration", () => {
    it("should maintain consistent error reporting", async () => {
      const orchestrator = new TypeSyncOrchestrator();

      // Test that error handling maintains backward compatibility
      global.fetch = vi.fn().mockRejectedValue(new Error("Connection refused"));

      const config: SyncOptions = {
        apiUrl: "http://localhost:8000",
        outputDir: "./generated",
        features: {
          client: true,
          hooks: true,
          streaming: true,
        },
      };

      await expect(orchestrator.syncOnce(config)).rejects.toThrow(
        "Connection refused"
      );
    });

    it("should provide consistent validation error messages", async () => {
      const orchestrator = new TypeSyncOrchestrator();

      // Test that schema validation errors are consistent
      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve({ invalid: "schema" }),
      });

      const config: SyncOptions = {
        apiUrl: "http://localhost:8000",
        outputDir: "./generated",
        features: {
          client: true,
          hooks: true,
          streaming: true,
        },
      };

      await expect(orchestrator.syncOnce(config)).rejects.toThrow();
    });
  });
});
