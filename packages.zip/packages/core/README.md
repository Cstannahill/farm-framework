# @farm/core

Minimal core utilities shared by other packages.

- **src/index.ts** – re-exports types from `@farm/types`, provides
  `defineConfig` helper and an `initialize` placeholder used by
  consumers.
