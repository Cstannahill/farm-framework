import React from 'react';

export default function ProductManager() {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-2">Product Manager</h2>
      {/* Product management UI */}
    </div>
  );
}
