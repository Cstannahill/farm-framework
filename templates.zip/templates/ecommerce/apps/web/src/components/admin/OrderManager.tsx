import React from 'react';

export default function OrderManager() {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-2">Order Manager</h2>
      {/* Order management UI */}
    </div>
  );
}
