# Placeholder PayPal client
class PayPalClient:
    def charge(self, amount: float, token: str):
        return {"status": "charged", "amount": amount}
