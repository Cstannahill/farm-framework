# basic inventory management placeholder
class InventoryManager:
    def reserve(self, product_id: int, quantity: int):
        pass
